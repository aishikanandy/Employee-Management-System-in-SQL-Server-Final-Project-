﻿----Project Title: Employee Management System in SQL Server

-----Objective: Create a database to manage employees and their departments.
-----Implement tables, relationships, and various SQL operations like joins, views, functions, stored procedures, and security roles.

CREATE DATABASE CompanyDB; --Creating Database
GO

USE CompanyDB;
GO

--Create 'Departments' table--

CREATE TABLE Departments
(
    DepartmentID INT PRIMARY KEY IDENTITY(1,1),
    DepartmentName NVARCHAR(100) NOT NULL
);

GO

--Create 'Employees' table--

CREATE TABLE Employees
(
    EmployeeID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DepartmentID INT FOREIGN KEY REFERENCES Departments(DepartmentID),
    Salary DECIMAL(10,2) NOT NULL
);

GO

--Insert sample data into the tables--

INSERT INTO Departments (DepartmentName)

VALUES

('Human Resources'),
('Finance'),
('IT'),
('Marketing'),
('Sales');

GO

INSERT INTO Employees (FirstName, LastName, DepartmentID, Salary)

VALUES

('Amit', 'Sharma', 1, 45000.00),   -- HR
('Sneha', 'Patel', 2, 55000.00),   -- Finance
('Rohan', 'Mehta', 3, 70000.00),   -- IT
('Priya', 'Nair', 3, 68000.00),    -- IT
('Arjun', 'Singh', 4, 50000.00),   -- Marketing
('Kavita', 'Rao', 5, 60000.00);    -- Sales

GO

---Perform queries: ○ Usejoins to retrieve employee names along with their department names.

SELECT 

E.EmployeeID,
E.FirstName + ' ' + E.LastName AS EmployeeName,
D.DepartmentName,
E.Salary

FROM Employees AS E

JOIN Departments AS D

ON E.DepartmentID = D.DepartmentID;

---○ Use OFFSET FETCH for pagination.

SELECT * FROM Employees

ORDER BY EmployeeID

OFFSET 1 ROWS     -- Skip first row

FETCH NEXT 5 ROWS ONLY;  -- Show next 5 rows

---Create a view that displays high-salaried employees (salary > 50000)--

CREATE VIEW vw_HighSalaryEmployees

AS

SELECT * FROM Employees

WHERE Salary>50000

--Query the view--

SELECT * FROM vw_HighSalaryEmployees;

---Create a user-defined function to calculate annual salary.---

CREATE FUNCTION dbo.AnnualSalary (@Salary DECIMAL(10,2))

RETURNS DECIMAL (10,2)

AS

BEGIN

    DECLARE @AnnualSalary DECIMAL (10,2)

    SET @AnnualSalary=(@Salary*12)

RETURN @AnnualSalary

END;

GO

--Query the function

SELECT 
    EmployeeID,
    FirstName,
    LastName,
    Salary AS MonthlySalary,
    dbo.AnnualSalary(Salary) AS AnnualSalary
FROM Employees;


--Create a stored procedure to insert a new employee record--

CREATE PROCEDURE InsertEmployee
@FirstName NVARCHAR(100),
@lastName NVARCHAR(100),
@DepartmentID INT,
@Salary DECIMAL(10,2)

AS

BEGIN

    INSERT INTO Employees(FirstName, LastName, DepartmentID, Salary)
    VALUES (@FirstName, @LastName, @DepartmentID, @Salary);

    PRINT 'Employee Details inserted successfully!';

END;

---Execute the stored procedure---

EXEC InsertEmployee
@FirstName='Somen',
@LastName='Guha',
@DepartmentID=1,
@Salary=30000.00;

---Work with server and database roles:
----○ Create a database role and assign permissions to view data.
----○ Assign a server role to manage database backup.

--Database role creation and assigning 'Select' permission--

CREATE ROLE DataViewer;
GRANT SELECT ON Employees TO DataViewer;

--Assigning role to a user--
ALTER ROLE DataViewer
ADD MEMBER someusername;

--Server Role:
--- Add a user to a server role (e.g., db_backupoperator for backups)

ALTER SERVER ROLE db_backupoperator
ADD MEMBER someusername;


---Conclusion---

----1. The project successfully demonstrated how to design a complete SQL Server system by creating databases, tables, relationships, constraints, views, functions, and stored procedures.

----2. It provided hands-on experience with essential SQL concepts such as joins, pagination, role management, and data manipulation.

----3. Overall, the project strengthened understanding of database design, security, and real-world SQL operations used in professional environments.
